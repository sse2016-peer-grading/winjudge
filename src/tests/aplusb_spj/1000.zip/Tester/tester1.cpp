#include <iostream>
#include "foo.h"

int main() {
  Calculator c(100);
  std::cout << c.add(100, 5) << std::endl;
}
