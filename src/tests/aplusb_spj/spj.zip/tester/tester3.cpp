#include <iostream>
#include "foo.h"

int main() {
  Calculator c;
  std::cout << c.multiply(100, 5) << std::endl;
}
