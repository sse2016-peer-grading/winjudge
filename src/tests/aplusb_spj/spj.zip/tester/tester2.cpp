#include <iostream>
#include "foo.h"

int main() {
  Calculator c;
  std::cout << c.minus(100, 5) << std::endl;
}
